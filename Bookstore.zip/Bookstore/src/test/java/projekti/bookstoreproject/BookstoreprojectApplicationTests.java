package projekti.bookstoreproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
